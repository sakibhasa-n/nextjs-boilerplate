<?php

use Illuminate\Support\Facades\Route;
use App\Http\Controllers\AuthController;
use App\Http\Controllers\WalletController;
use App\Http\Controllers\Admin\AdminController;

// Public Auth routes
Route::post('/auth/register', [AuthController::class, 'register']);
Route::post('/auth/login', [AuthController::class, 'login']);

// Authenticated Player routes
Route::middleware('auth:sanctum')->group(function () {
    Route::post('/auth/logout', [AuthController::class, 'logout']);
    Route::post('/auth/set-trx-password', [AuthController::class, 'setTransactionPassword']);
    
    // Wallet actions
    Route::post('/wallet/deposit', [WalletController::class, 'deposit']);
    Route::post('/wallet/withdraw', [WalletController::class, 'withdraw']);
});

// Admin Panel Protected routes
Route::middleware(['auth:sanctum', 'role:admin'])->prefix('admin')->group(function () {
    Route::get('/dashboard', [AdminController::class, 'dashboard']);
    Route::post('/users/{id}/balance', [AdminController::class, 'adjustUserBalance']);
    Route::post('/transactions/{id}/process', [AdminController::class, 'handleTransaction']);
});

// Provider Seamless Game Callbacks (Jili, PG Soft, Pragmatic)
Route::post('/games/callback/{provider}', function ($provider, \Illuminate\Http\Request $request) {
    $manager = new \App\ApiSetup\ProviderManager();
    $driver = $manager->driver($provider);
    return response()->json($driver->processSeamlessTransaction($request->all()));
});
