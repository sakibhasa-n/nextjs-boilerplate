<?php

namespace App\ApiSetup\Providers;

use App\ApiSetup\Contracts\GameProviderInterface;
use App\ApiSetup\Helpers\CryptoHelper;
use Illuminate\Support\Facades\Http;
use Illuminate\Support\Facades\Log;
use Exception;

class JiliProvider implements GameProviderInterface
{
    protected string $apiUrl;
    protected string $merchantCode;
    protected string $secretKey;
    protected string $agentCode;
    protected string $currency = 'BDT';

    public function __construct(array $config)
    {
        $this->apiUrl = rtrim($config['api_url'] ?? 'https://api.jiligames.com/api1', '/');
        $this->merchantCode = $config['merchant_code'] ?? '';
        $this->secretKey = $config['secret_key'] ?? '';
        $this->agentCode = $config['agent_code'] ?? 'AG_LIVEXWIN';
        $this->currency = $config['currency'] ?? 'BDT';
    }

    public function getProviderCode(): string
    {
        return 'jili';
    }

    public function fetchGameList(): array
    {
        try {
            $timestamp = time();
            $params = [
                'AgentId' => $this->agentCode,
                'Timestamp' => $timestamp,
            ];
            $keyG = md5($timestamp . $this->agentCode . $this->secretKey);
            $params['Key'] = $keyG;

            $response = Http::timeout(15)->get("{$this->apiUrl}/GetGameList", $params);

            if (!$response->successful()) {
                throw new Exception("JILI HTTP Error: " . $response->body());
            }

            $data = $response->json();
            $games = [];

            if (($data['ErrorCode'] ?? -1) === 0 && !empty($data['Data'])) {
                foreach ($data['Data'] as $item) {
                    $games[] = [
                        'provider_id' => 'jili',
                        'game_code' => (string)($item['GameId'] ?? ''),
                        'name' => $item['GameName']['en-US'] ?? $item['GameName'] ?? 'JILI Game',
                        'bengali_name' => $item['GameName']['bn-BD'] ?? $item['GameName'] ?? 'জিলি গেম',
                        'category' => $this->mapCategory($item['GameType'] ?? 1),
                        'image' => $item['IconUrl'] ?? '',
                        'rtp' => 97.4,
                        'is_active' => true,
                    ];
                }
            }
            return $games;
        } catch (Exception $e) {
            Log::error("JILI FetchGameList Failed: " . $e->getMessage());
            return [];
        }
    }

    public function launchGame($userId, string $gameCode, string $lang = 'bn', array $extraOptions = []): string
    {
        $timestamp = time();
        $account = "usr_" . $userId;
        
        // Jili launch token payload
        $postData = [
            'Account' => $account,
            'GameId' => (int)$gameCode,
            'Lang' => $lang === 'bn' ? 'bn-BD' : 'en-US',
            'AgentId' => $this->agentCode,
            'Currency' => $this->currency,
            'HomeUrl' => config('app.url'),
            'Timestamp' => $timestamp,
        ];

        $rawSign = $timestamp . $this->agentCode . $this->secretKey;
        $postData['Key'] = md5($rawSign);

        $response = Http::asJson()->timeout(10)->post("{$this->apiUrl}/Login", $postData);
        $res = $response->json();

        if (($res['ErrorCode'] ?? -1) === 0 && !empty($res['Data'])) {
            return $res['Data']; // Launch URL returned by JILI
        }

        throw new Exception("JILI Launch Failed: " . ($res['Message'] ?? 'Unknown Error'));
    }

    public function checkPlayerBalance(string $playerToken): float
    {
        // Query database for player balance in BDT
        $userId = str_replace('usr_', '', $playerToken);
        $user = \App\Models\User::with('wallet')->find($userId);
        return $user && $user->wallet ? (float)$user->wallet->balance : 0.00;
    }

    public function processSeamlessTransaction(array $payload): array
    {
        $account = $payload['Account'] ?? '';
        $userId = str_replace('usr_', '', $account);
        $betAmount = (float)($payload['BetAmount'] ?? 0);
        $winAmount = (float)($payload['WinAmount'] ?? 0);
        $roundId = $payload['RoundIndex'] ?? uniqid('jili_');

        $user = \App\Models\User::with('wallet')->findOrFail($userId);
        $wallet = $user->wallet;

        // Atomically deduct bet and credit win
        $netChange = $winAmount - $betAmount;
        $wallet->balance += $netChange;
        $wallet->save();

        // Record bet log
        \App\Models\BetLog::create([
            'user_id' => $user->id,
            'game_code' => $payload['GameId'] ?? 'jili',
            'provider' => 'jili',
            'bet_amount' => $betAmount,
            'payout_amount' => $winAmount,
            'profit' => $netChange,
            'round_id' => $roundId,
        ]);

        return [
            'ErrorCode' => 0,
            'Message' => 'Success',
            'Data' => [
                'Balance' => $wallet->balance,
            ],
        ];
    }

    public function verifySignature(array $headers, string $rawBody): bool
    {
        $expectedKey = $headers['x-jili-signature'][0] ?? $headers['X-Jili-Signature'] ?? null;
        if (!$expectedKey) return false;
        return hash_equals(hash_hmac('sha256', $rawBody, $this->secretKey), $expectedKey);
    }

    private function mapCategory(int $type): string
    {
        return match ($type) {
            1 => 'slots',
            5 => 'fishing',
            2 => 'poker',
            default => 'hot',
        };
    }
}
