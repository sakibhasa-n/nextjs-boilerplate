<?php

namespace App\ApiSetup\Providers;

use App\ApiSetup\Contracts\GameProviderInterface;
use Illuminate\Support\Facades\Http;
use Exception;

class PragmaticPlayProvider implements GameProviderInterface
{
    protected string $apiUrl;
    protected string $secureLogin;
    protected string $secretKey;
    protected string $currency = 'BDT';

    public function __construct(array $config)
    {
        $this->apiUrl = $config['api_url'] ?? 'https://api.pragmaticplay.net/gs2c';
        $this->secureLogin = $config['merchant_code'] ?? 'PP_LIVEXWIN';
        $this->secretKey = $config['secret_key'] ?? '';
        $this->currency = $config['currency'] ?? 'BDT';
    }

    public function getProviderCode(): string
    {
        return 'pragmatic';
    }

    public function fetchGameList(): array
    {
        return [
            [
                'provider_id' => 'pragmatic',
                'game_code' => 'vs20sweetbonanza',
                'name' => 'Sweet Bonanza 1000',
                'bengali_name' => 'মিষ্টি বোনাম্বু 1000',
                'category' => 'slots',
                'rtp' => 96.6,
            ],
            [
                'provider_id' => 'pragmatic',
                'game_code' => 'vs20olympx',
                'name' => 'Gates of Olympus 1000',
                'bengali_name' => 'গেটস অফ অলিম্পাস 1000',
                'category' => 'slots',
                'rtp' => 96.5,
            ]
        ];
    }

    public function launchGame($userId, string $gameCode, string $lang = 'bn', array $extraOptions = []): string
    {
        $token = md5($userId . time() . $this->secretKey);
        
        $params = http_build_query([
            'symbol' => $gameCode,
            'gamedir' => 'vs20olympx',
            'token' => $token,
            'language' => $lang === 'bn' ? 'bn' : 'en',
            'currency' => $this->currency,
            'lobbyURL' => config('app.url'),
        ]);

        return "{$this->apiUrl}/playGame.do?{$params}";
    }

    public function checkPlayerBalance(string $playerToken): float
    {
        return 0.0;
    }

    public function processSeamlessTransaction(array $payload): array
    {
        return ['error' => 0, 'description' => 'Success'];
    }

    public function verifySignature(array $headers, string $rawBody): bool
    {
        return true;
    }
}
