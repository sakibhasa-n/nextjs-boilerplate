<?php

namespace App\ApiSetup\Providers;

use App\ApiSetup\Contracts\GameProviderInterface;
use Illuminate\Support\Facades\Http;
use Illuminate\Support\Facades\Log;
use Exception;

class PGSoftProvider implements GameProviderInterface
{
    protected string $apiUrl;
    protected string $operatorToken;
    protected string $secretKey;
    protected string $currency = 'BDT';

    public function __construct(array $config)
    {
        $this->apiUrl = rtrim($config['api_url'] ?? 'https://api.pgsoft.com/v2', '/');
        $this->operatorToken = $config['merchant_code'] ?? 'PG_LIVEXWIN_PRO';
        $this->secretKey = $config['secret_key'] ?? '';
        $this->currency = $config['currency'] ?? 'BDT';
    }

    public function getProviderCode(): string
    {
        return 'pgsoft';
    }

    public function fetchGameList(): array
    {
        try {
            $response = Http::asForm()->post("{$this->apiUrl}/Game/Get", [
                'operator_token' => $this->operatorToken,
                'secret_key' => $this->secretKey,
                'currency' => $this->currency,
            ]);

            $json = $response->json();
            $games = [];

            if (($json['data'] ?? null) && is_array($json['data'])) {
                foreach ($json['data'] as $item) {
                    $games[] = [
                        'provider_id' => 'pgsoft',
                        'game_code' => (string)$item['game_id'],
                        'name' => $item['game_name'],
                        'category' => 'slots',
                        'image' => "https://m.pgsoft.com/games/icons/{$item['game_id']}.png",
                        'rtp' => 96.8,
                    ];
                }
            }
            return $games;
        } catch (Exception $e) {
            Log::error("PG Soft GetGameList error: " . $e->getMessage());
            return [];
        }
    }

    public function launchGame($userId, string $gameCode, string $lang = 'bn', array $extraOptions = []): string
    {
        $opsToken = md5($userId . time() . $this->secretKey);
        
        $params = http_build_query([
            'btt' => 1,
            'ops' => $opsToken,
            'l' => $lang === 'bn' ? 'bn' : 'en',
            'fi' => $gameCode,
            'ot' => $this->operatorToken,
        ]);

        return "https://m.pgsoft.com/{$gameCode}/index.html?{$params}";
    }

    public function checkPlayerBalance(string $playerToken): float
    {
        $user = \App\Models\User::with('wallet')->find($playerToken);
        return $user && $user->wallet ? (float)$user->wallet->balance : 0.00;
    }

    public function processSeamlessTransaction(array $payload): array
    {
        return [
            'data' => ['balance' => 0],
            'error' => null,
        ];
    }

    public function verifySignature(array $headers, string $rawBody): bool
    {
        return true;
    }
}
