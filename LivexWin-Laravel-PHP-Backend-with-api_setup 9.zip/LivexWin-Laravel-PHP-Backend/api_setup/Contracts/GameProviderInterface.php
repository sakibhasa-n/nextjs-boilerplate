<?php

namespace App\ApiSetup\Contracts;

interface GameProviderInterface
{
    /**
     * Get the unique code for this provider (e.g. 'jili', 'pgsoft')
     */
    public function getProviderCode(): string;

    /**
     * Fetch complete game catalog list from provider API
     * @return array<int, array{id: string, name: string, category: string, image: string, rtp: float}>
     */
    public function fetchGameList(): array;

    /**
     * Generate secure launch game session URL for a player
     * @param int|string $userId
     * @param string $gameCode
     * @param string $lang (bn|en)
     * @param array $extraOptions
     * @return string
     */
    public function launchGame($userId, string $gameCode, string $lang = 'bn', array $extraOptions = []): string;

    /**
     * Seamless Wallet: Query player balance callback
     * @param string $playerToken
     * @return float
     */
    public function checkPlayerBalance(string $playerToken): float;

    /**
     * Seamless Wallet: Settle bet/win transaction from game spin
     * @param array $payload
     * @return array
     */
    public function processSeamlessTransaction(array $payload): array;

    /**
     * Verify incoming webhook signature to prevent tampering
     * @param array $headers
     * @param string $rawBody
     * @return bool
     */
    public function verifySignature(array $headers, string $rawBody): bool;
}
