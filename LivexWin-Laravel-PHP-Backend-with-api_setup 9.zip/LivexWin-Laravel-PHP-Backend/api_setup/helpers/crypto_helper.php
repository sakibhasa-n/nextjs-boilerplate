<?php

namespace App\ApiSetup\Helpers;

class CryptoHelper
{
    public static function aesEncrypt(string $data, string $key, string $iv): string
    {
        return openssl_encrypt($data, 'AES-128-CBC', $key, OPENSSL_RAW_DATA, $iv);
    }

    public static function aesDecrypt(string $cipher, string $key, string $iv): string
    {
        return openssl_decrypt($cipher, 'AES-128-CBC', $key, OPENSSL_RAW_DATA, $iv);
    }

    public static function generateSignature(array $params, string $secret): string
    {
        ksort($params);
        $query = http_build_query($params);
        return hash_hmac('sha256', $query, $secret);
    }
}
