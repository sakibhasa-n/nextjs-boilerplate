<?php

require_once __DIR__ . '/../../vendor/autoload.php';

use App\ApiSetup\ProviderManager;

$config = require __DIR__ . '/../config/game_providers.php';
$manager = new ProviderManager($config);

// 1. Fetch JILI Games
try {
    echo "Fetching JILI games catalog...\n";
    $jili = $manager->driver('jili');
    $games = $jili->fetchGameList();
    echo "Found " . count($games) . " games from JILI.\n";
    print_r(array_slice($games, 0, 3));
} catch (Exception $e) {
    echo "Error: " . $e->getMessage() . "\n";
}
