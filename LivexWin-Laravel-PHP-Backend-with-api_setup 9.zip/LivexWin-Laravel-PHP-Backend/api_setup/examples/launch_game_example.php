<?php

require_once __DIR__ . '/../../vendor/autoload.php';

use App\ApiSetup\ProviderManager;

$config = require __DIR__ . '/../config/game_providers.php';
$manager = new ProviderManager($config);

try {
    $playerId = 1206248521;
    $gameCode = 'jili-super-ace';
    
    echo "Generating launch session for Player: $playerId on Game: $gameCode\n";
    $jili = $manager->driver('jili');
    $launchUrl = $jili->launchGame($playerId, $gameCode, 'bn');
    
    echo "Launch URL: " . $launchUrl . "\n";
} catch (Exception $e) {
    echo "Launch error: " . $e->getMessage() . "\n";
}
