<?php

namespace App\ApiSetup;

use App\ApiSetup\Contracts\GameProviderInterface;
use App\ApiSetup\Providers\JiliProvider;
use App\ApiSetup\Providers\PGSoftProvider;
use App\ApiSetup\Providers\PragmaticPlayProvider;
use InvalidArgumentException;

class ProviderManager
{
    protected array $drivers = [];
    protected array $config;

    public function __construct(array $config = [])
    {
        $this->config = $config ?: config('game_providers', []);
    }

    /**
     * Get or build provider driver
     */
    public function driver(string $provider): GameProviderInterface
    {
        $key = strtolower($provider);
        if (isset($this->drivers[$key])) {
            return $this->drivers[$key];
        }

        $providerConfig = $this->config['providers'][$key] ?? null;
        if (!$providerConfig) {
            throw new InvalidArgumentException("Game provider [$provider] is not configured.");
        }

        $instance = match ($key) {
            'jili' => new JiliProvider($providerConfig),
            'pgsoft', 'pocket games soft' => new PGSoftProvider($providerConfig),
            'pragmatic', 'pragmatic play' => new PragmaticPlayProvider($providerConfig),
            default => throw new InvalidArgumentException("Unsupported provider driver [$provider]"),
        };

        return $this->drivers[$key] = $instance;
    }
}
