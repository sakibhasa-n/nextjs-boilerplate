<?php

return [
    'default_currency' => env('GAME_CURRENCY', 'BDT'),
    'seamless_wallet_mode' => true,

    'providers' => [
        'jili' => [
            'name' => 'JILI Games',
            'api_url' => env('JILI_API_URL', 'https://api.jiligames.com/api1'),
            'merchant_code' => env('JILI_MERCHANT_CODE', 'LIVEXWIN_BD_01'),
            'secret_key' => env('JILI_SECRET_KEY', 'jl_sec_993847291048591823'),
            'agent_code' => env('JILI_AGENT_CODE', 'AG_LIVEXWIN'),
            'currency' => 'BDT',
            'timeout' => 15,
        ],
        'pgsoft' => [
            'name' => 'Pocket Games Soft',
            'api_url' => env('PG_API_URL', 'https://api.pgsoft.com/v2'),
            'merchant_code' => env('PG_MERCHANT_CODE', 'PG_LIVEXWIN_PRO'),
            'secret_key' => env('PG_SECRET_KEY', 'pg_sec_283918204918293841'),
            'currency' => 'BDT',
            'timeout' => 15,
        ],
        'pragmatic' => [
            'name' => 'Pragmatic Play',
            'api_url' => env('PP_API_URL', 'https://api.pragmaticplay.net/gs2c'),
            'merchant_code' => env('PP_MERCHANT_CODE', 'PP_LIVEXWIN_LIVE'),
            'secret_key' => env('PP_SECRET_KEY', 'pp_sec_581920394810293849'),
            'currency' => 'BDT',
            'timeout' => 15,
        ],
    ],
];
