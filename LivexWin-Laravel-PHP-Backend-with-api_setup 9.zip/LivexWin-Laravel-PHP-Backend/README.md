# LivexWin Casino - Laravel PHP Backend & API Setup

This package contains the complete, production-grade Laravel PHP backend for **LivexWin** (clone of 60bd98.vip) with:
1. **Dedicated `api_setup/` folder** with plug-and-play drivers for **JILI**, **Pocket Games Soft (PG)**, and **Pragmatic Play**.
2. **Secure Authentication** with bcrypt passwords, Sanctum tokens, and transaction passwords.
3. **BDT Player Balances** with atomic transactions and pessimistic locking (`lockForUpdate`).
4. **Nagad, bKash & Rocket Payment Gateways** with TrxID validation.
5. **Full Admin Control Panel API** for managing users, approving withdrawals, and adjusting balances.

## Quick Installation

```bash
# 1. Install Composer dependencies
composer install

# 2. Configure environment
cp .env.example .env
php artisan key:generate

# 3. Configure MySQL database in .env and run migrations
php artisan migrate --seed

# 4. Run local server
php artisan serve
```

## `api_setup/` Structure
- `Contracts/GameProviderInterface.php`: Standard provider interface.
- `Providers/JiliProvider.php`: JILI games list sync and launch engine.
- `Providers/PGSoftProvider.php`: PG Soft games launcher and operator token.
- `Providers/PragmaticPlayProvider.php`: Pragmatic Play casino service.
- `ProviderManager.php`: Factory pattern for resolving providers.
- `examples/`: Standalone runnable scripts for testing API ping and game launches.
