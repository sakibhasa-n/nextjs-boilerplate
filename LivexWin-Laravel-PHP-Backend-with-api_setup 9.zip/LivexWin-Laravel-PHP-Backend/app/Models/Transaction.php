<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;

class Transaction extends Model
{
    protected $fillable = [
        'user_id',
        'type',
        'amount',
        'status',
        'method',
        'channel',
        'trx_id',
        'account_number',
        'note',
    ];

    public function user()
    {
        return $this->belongsTo(User::class);
    }
}
