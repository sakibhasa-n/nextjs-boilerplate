<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;

class Wallet extends Model
{
    protected $fillable = [
        'user_id',
        'balance',
        'frozen_balance',
        'currency',
    ];

    protected $casts = [
        'balance' => 'float',
        'frozen_balance' => 'float',
    ];

    public function user()
    {
        return $this->belongsTo(User::class);
    }
}
