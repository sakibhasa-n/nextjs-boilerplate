<?php

namespace App\Http\Controllers\Admin;

use App\Http\Controllers\Controller;
use App\Models\User;
use App\Models\Wallet;
use App\Models\Transaction;
use App\Models\Game;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\DB;

class AdminController extends Controller
{
    /**
     * Dashboard statistics overview
     */
    public function dashboard()
    {
        $totalUsers = User::where('role', 'player')->count();
        $totalDeposits = Transaction::where('type', 'deposit')->where('status', 'approved')->sum('amount');
        $totalWithdrawals = Transaction::where('type', 'withdraw')->where('status', 'approved')->sum('amount');
        $pendingApprovals = Transaction::where('status', 'pending')->count();

        return response()->json([
            'total_users' => $totalUsers,
            'total_deposits' => $totalDeposits,
            'total_withdrawals' => $totalWithdrawals,
            'net_revenue' => $totalDeposits - $totalWithdrawals,
            'pending_approvals' => $pendingApprovals,
        ]);
    }

    /**
     * Adjust user balance manually
     */
    public function adjustUserBalance(Request $request, $userId)
    {
        $request->validate([
            'amount' => 'required|numeric',
            'action' => 'required|in:credit,debit',
            'reason' => 'required|string',
        ]);

        return DB::transaction(function () use ($request, $userId) {
            $wallet = Wallet::where('user_id', $userId)->lockForUpdate()->firstOrFail();
            $delta = $request->action === 'credit' ? abs($request->amount) : -abs($request->amount);

            $wallet->balance += $delta;
            $wallet->save();

            Transaction::create([
                'user_id' => $userId,
                'type' => $request->action === 'credit' ? 'bonus' : 'withdraw',
                'amount' => abs($request->amount),
                'status' => 'approved',
                'note' => "অ্যাডমিন অ্যাডজাস্টমেন্ট: " . $request->reason,
            ]);

            return response()->json(['success' => true, 'new_balance' => $wallet->balance]);
        });
    }

    /**
     * Approve or reject pending deposit / withdrawal
     */
    public function handleTransaction(Request $request, $id)
    {
        $request->validate([
            'action' => 'required|in:approve,reject',
            'note' => 'nullable|string',
        ]);

        return DB::transaction(function () use ($request, $id) {
            $tx = Transaction::lockForUpdate()->findOrFail($id);
            if ($tx->status !== 'pending') {
                return response()->json(['success' => false, 'message' => 'Transaction already processed'], 400);
            }

            if ($request->action === 'approve') {
                $tx->status = 'approved';
                if ($tx->type === 'deposit') {
                    // Credit player wallet
                    $wallet = Wallet::where('user_id', $tx->user_id)->first();
                    $wallet->balance += $tx->amount;
                    $wallet->save();
                }
            } else {
                $tx->status = 'rejected';
                if ($tx->type === 'withdraw') {
                    // Refund player wallet
                    $wallet = Wallet::where('user_id', $tx->user_id)->first();
                    $wallet->balance += $tx->amount;
                    $wallet->save();
                }
            }

            $tx->save();
            return response()->json(['success' => true, 'status' => $tx->status]);
        });
    }
}
