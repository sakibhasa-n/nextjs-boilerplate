<?php

namespace App\Http\Controllers;

use App\Models\User;
use App\Models\Wallet;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Hash;
use Illuminate\Support\Facades\Validator;
use Illuminate\Support\Facades\DB;

class AuthController extends Controller
{
    /**
     * Register a new player with BDT wallet and ৳60 welcome bonus
     */
    public function register(Request $request)
    {
        $validator = Validator::make($request->all(), [
            'username' => 'required|string|min:4|max:20|unique:users,username',
            'phone' => 'required|string|regex:/^(?:\\+88|88)?(01[3-9]\\d{8})$/|unique:users,phone',
            'password' => 'required|string|min:6',
            'invitation_code' => 'nullable|string',
        ]);

        if ($validator->fails()) {
            return response()->json(['success' => false, 'errors' => $validator->errors()], 422);
        }

        return DB::transaction(function () use ($request) {
            $user = User::create([
                'username' => strtolower(trim($request->username)),
                'nickname' => $request->username,
                'phone' => $request->phone,
                'password' => Hash::make($request->password),
                'role' => 'player',
                'status' => 'active',
                'vip_level' => 0,
                'invitation_code' => $request->invitation_code,
            ]);

            // Create player wallet with ৳60 free registration bonus
            $wallet = Wallet::create([
                'user_id' => $user->id,
                'balance' => 60.00,
                'currency' => 'BDT',
            ]);

            $token = $user->createToken('livexwin_token')->plainTextToken;

            return response()->json([
                'success' => true,
                'message' => 'রেজিস্ট্রেশন সফল হয়েছে! ৳৬০ বোনাস যোগ হয়েছে।',
                'user' => $user->load('wallet'),
                'token' => $token,
            ], 201);
        });
    }

    /**
     * Authenticate player or admin
     */
    public function login(Request $request)
    {
        $request->validate([
            'login' => 'required|string', // username or phone
            'password' => 'required|string',
        ]);

        $login = strtolower(trim($request->login));
        $user = User::where('username', $login)
                    ->orWhere('phone', $login)
                    ->with('wallet')
                    ->first();

        if (!$user || !Hash::check($request->password, $user->password)) {
            return response()->json(['success' => false, 'message' => 'ইউজারনেম অথবা পাসওয়ার্ড ভুল হয়েছে।'], 401);
        }

        if ($user->status === 'banned') {
            return response()->json(['success' => false, 'message' => 'আপনার অ্যাকাউন্ট সাময়িকভাবে স্থগিত রয়েছে।'], 403);
        }

        $token = $user->createToken('livexwin_token')->plainTextToken;

        return response()->json([
            'success' => true,
            'message' => 'লগইন সফল হয়েছে!',
            'user' => $user,
            'token' => $token,
        ]);
    }

    /**
     * Set transaction password (required for withdrawals)
     */
    public function setTransactionPassword(Request $request)
    {
        $request->validate([
            'trx_password' => 'required|string|min:6|max:6',
        ]);

        $user = $request->user();
        $user->trx_password = Hash::make($request->trx_password);
        $user->save();

        return response()->json(['success' => true, 'message' => 'লেনদেন পাসওয়ার্ড সফলভাবে সংরক্ষিত হয়েছে।']);
    }

    /**
     * Logout
     */
    public function logout(Request $request)
    {
        $request->user()->currentAccessToken()->delete();
        return response()->json(['success' => true, 'message' => 'লগআউট সম্পন্ন হয়েছে।']);
    }
}
