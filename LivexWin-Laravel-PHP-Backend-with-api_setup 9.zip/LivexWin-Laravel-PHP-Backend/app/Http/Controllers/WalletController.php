<?php

namespace App\Http\Controllers;

use App\Models\Transaction;
use App\Models\Wallet;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\DB;
use Illuminate\Support\Facades\Hash;

class WalletController extends Controller
{
    /**
     * Submit Deposit Request
     */
    public function deposit(Request $request)
    {
        $request->validate([
            'amount' => 'required|numeric|min:100|max:50000',
            'method' => 'required|in:nagad,bkash,rocket',
            'channel' => 'required|string',
            'trx_id' => 'required|string|min:6|max:30|unique:transactions,trx_id',
            'sender_number' => 'required|string',
        ]);

        $user = $request->user();

        $transaction = Transaction::create([
            'user_id' => $user->id,
            'type' => 'deposit',
            'amount' => $request->amount,
            'method' => $request->method,
            'channel' => $request->channel,
            'trx_id' => strtoupper($request->trx_id),
            'account_number' => $request->sender_number,
            'status' => 'pending', // Reviewed in Admin Panel
        ]);

        return response()->json([
            'success' => true,
            'message' => 'ডিপোজিট অনুরোধ গৃহীত হয়েছে! ট্রানজেকশন যাচাই করে দ্রুত ব্যালেন্স যুক্ত হবে।',
            'transaction' => $transaction,
        ]);
    }

    /**
     * Submit Withdrawal Request
     */
    public function withdraw(Request $request)
    {
        $request->validate([
            'amount' => 'required|numeric|min:100|max:25000',
            'method' => 'required|in:nagad,bkash',
            'account_number' => 'required|string',
            'trx_password' => 'required|string',
        ]);

        $user = $request->user();

        if (!Hash::check($request->trx_password, $user->trx_password)) {
            return response()->json(['success' => false, 'message' => 'ভুল লেনদেন পাসওয়ার্ড!'], 422);
        }

        return DB::transaction(function () use ($request, $user) {
            $wallet = Wallet::where('user_id', $user->id)->lockForUpdate()->firstOrFail();

            if ($wallet->balance < $request->amount) {
                return response()->json(['success' => false, 'message' => 'পর্যাপ্ত ব্যালেন্স নেই!'], 400);
            }

            // Deduct immediately and put in pending withdrawal
            $wallet->balance -= $request->amount;
            $wallet->save();

            $transaction = Transaction::create([
                'user_id' => $user->id,
                'type' => 'withdraw',
                'amount' => $request->amount,
                'method' => $request->method,
                'account_number' => $request->account_number,
                'status' => 'pending',
            ]);

            return response()->json([
                'success' => true,
                'message' => 'উত্তোলন অনুরোধ সফল হয়েছে! অ্যাডমিন অনুমোদনের পর টাকা পৌঁছে যাবে।',
                'transaction' => $transaction,
                'new_balance' => $wallet->balance,
            ]);
        });
    }
}
