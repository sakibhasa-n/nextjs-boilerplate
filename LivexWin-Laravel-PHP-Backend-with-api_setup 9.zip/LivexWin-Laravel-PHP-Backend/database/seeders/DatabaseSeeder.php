<?php

namespace Database\Seeders;

use Illuminate\Database\Seeder;
use Illuminate\Support\Facades\Hash;
use App\Models\User;
use App\Models\Wallet;

class DatabaseSeeder extends Seeder
{
    public function run(): void
    {
        // 1. Super Admin
        $admin = User::firstOrCreate(
            ['username' => 'admin'],
            [
                'nickname' => 'Super Manager',
                'phone' => '01888888888',
                'password' => Hash::make('admin123'),
                'trx_password' => Hash::make('123456'),
                'role' => 'admin',
                'status' => 'active',
                'vip_level' => 10,
            ]
        );

        Wallet::firstOrCreate(
            ['user_id' => $admin->id],
            ['balance' => 9999999.00, 'currency' => 'BDT']
        );

        // 2. Demo Player matching 60BD screenshot
        $player = User::firstOrCreate(
            ['username' => 't1206248521'],
            [
                'nickname' => 't1206248521',
                'phone' => '01712062485',
                'password' => Hash::make('player123'),
                'trx_password' => Hash::make('123456'),
                'role' => 'player',
                'status' => 'active',
                'vip_level' => 0,
            ]
        );

        Wallet::firstOrCreate(
            ['user_id' => $player->id],
            ['balance' => 500.00, 'currency' => 'BDT']
        );
    }
}
