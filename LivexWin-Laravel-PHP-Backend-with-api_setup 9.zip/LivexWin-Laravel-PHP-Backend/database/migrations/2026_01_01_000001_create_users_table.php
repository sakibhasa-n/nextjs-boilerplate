<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration
{
    public function up(): void
    {
        Schema::create('users', function (Blueprint $table) {
            $table->id();
            $table->string('username')->unique();
            $table->string('nickname')->nullable();
            $table->string('phone')->unique();
            $table->string('password');
            $table->string('trx_password')->nullable();
            $table->string('avatar')->default('default_avatar.png');
            $table->enum('role', ['player', 'admin', 'superadmin'])->default('player');
            $table->enum('status', ['active', 'banned', 'suspended'])->default('active');
            $table->unsignedTinyInteger('vip_level')->default(0);
            $table->string('invitation_code')->nullable();
            $table->rememberToken();
            $table->timestamps();
        });
    }

    public function down(): void
    {
        Schema::dropIfExists('users');
    }
};
